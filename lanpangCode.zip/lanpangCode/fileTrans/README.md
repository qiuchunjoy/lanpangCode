# transCargoData.py usage
## 1.install python
go for https://www.python.org/ webside and download Python 3.10.2
## 2.install libraries
pip install -r requirements.txt
only here need request and pytest related libraries, you can get the detailed version in requirements.txt file
## 3.run scripts
enter code directory and then run python transCargoData.py
## 4.output
you can get output file in out.json
## 5.error message
you can get error message in time when you run the scripts