import json

class CargoDataSource:
    # define a load method, using for load data from cargo.csv file
    def load(self, input_file_path):
        # open the input cargo.csv file then handle
        with open(input_file_path, 'r') as f:
            # initial varibles
            lines = f.readlines()
            self.index_list = []
            self.str = ''
            self.lst = []

            # check cargo.csv has right data
            if not lines:
                print('File error')
            else:
                # go overthrough the file, then trans data to what's we need
                for line in lines:
                    # make lines in the cargo.csv file to small pieces then we can go next step to handle data
                    this_lines = line.split(',')
                    self.dimensions = this_lines[1].split('*')
                    self.weight = this_lines[0]
                    self.destination = this_lines[2]
                    self.index = this_lines[3]

                    # check index is the only one in the file
                    if self.index not in self.index_list:
                        self.index_list.append(self.index)
                    else:
                        print('This data exist same index', this_lines)
                        continue
                    
                    # check cargo.csv data only have 4 elements each line
                    if len(this_lines) == 4:
                        # **Weight** must lager than 10, and kg is the only legal unit。
                        # **Weight** （重量）值必须大于 10。单位是可选的，但“kg”是唯一允许的单位。
                        if self.weight[-2:] == 'kg' and self.weight[:-2].isdigit and int(self.weight[:-2]) > 10:
                            # check dimensions available,check dimensions has 3 elements, length,width,height
                            if len(self.dimensions) == 3:
                                # **Dimensions** （尺寸）由“\*”字符分隔。单位是必需的，“cm”和“mm”是唯一允许的两个单位，但不能同时使用（所以1cm\*2cm\*3mm无效）。每个维度值必须大于 0。
                                # check dimensions unit, then put it into a list
                                if self.dimensions[0][-2:] == self.dimensions[1][-2:] == self.dimensions[2][-2:] and self.dimensions[0][-2:] in ['mm', 'cm']:
                                    self.str = '{"weight":'+self.weight[:-2]+",\"length\":"+self.dimensions[0][:-2]+','+'"width":'+self.dimensions[1][:-2]+','+'"height":' +\
                                        self.dimensions[2][:-2]+','+'"dim_unit":'+'\"'+self.dimensions[0][-2:]+'\"'+',' + \
                                        '"destination":'+'\"'+self.destination+'\"' + \
                                        ','+'"index":' + \
                                            self.index.strip('\n')+'}'
                                    self.lst.append(self.str)
                                # error handle
                                else:
                                    print(
                                        'dimensions error, unit not cm or mm: ', this_lines)
                            else:
                                print(
                                    'dimensions error, not contain width\height\length: ', this_lines)
                        else:
                            print('weight unit error: ', this_lines)
                    else:
                        print('data error, column error: ', this_lines)
                # renturn list
                return self.lst

    # define a export data method
    def export(self, output_file_path):
        with open(output_file_path, 'w+') as f:
            f.write(str(self.lst).replace('\'', ''))

    # define a check the file differences method
    def diff(self, source_1, source_2):
        f1 = open(source_1, 'r')
        f2 = open(source_2, 'r')
        self.count = 0
        self.diff = []
        self.diff_content = []
        for line2 in f2:
            line1 = f1.readline()
            self.count += 1
            if line1 != line2:
                self.diff.append(self.count)
                self.diff_content.append(line1)
        f1.close()
        f2.close()
        # print(self.diff)
        # print(self.diff_content)
        return self.diff, self.diff_content


if __name__ == '__main__':
    # initial Cargo class
    cd = CargoDataSource()
    # use load method
    cd.load('./cargo.csv')
    # use export method
    cd.export('./out.json')

    # use diff method
    differ = cd.diff('./source1.data', './source2.data')

    if len(differ[0]) == 0:
        print('--- The Two file the same')
    else:
        print('--- The Two file has %d difference' % len(differ))
        for each in differ[0]:
            print('The %d row not same' % each)
        for each in differ[1]:
            print(each)
