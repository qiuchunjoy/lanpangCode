
import random

login = {"url_login": "https://interview.doraclp.cn/login/",
         "email": "admin@example.com",
         "password": "password"}
login_notExistsUser = {"url_login": "https://interview.doraclp.cn/login/",
         "email": "notExistsUser@example.com",
         "password": "password"}
registration = {"url_registration": "https://interview.doraclp.cn/register/",
                "email": "admin999"+str(random.randint(1000,9999))+"@example.com",
                "password": "password",
                "firstName": "John",
                "lastName": "Smith"}
registration_emailError = {"url_registration": "https://interview.doraclp.cn/register/",
                "email": "notExists",
                "password": "password",
                "firstName": "John",
                "lastName": "Smith"}