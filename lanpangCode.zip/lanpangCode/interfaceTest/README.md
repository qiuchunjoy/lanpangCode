# Usage
## 1.method one
you can use below command to got a html report through pytest, and then you can see the results in makehtml.html file
pytest -q --tb=no --html=.\makehtml.html
## 2.method two
you can use test_login_notExistsUser() in main method run the method directly