import requests
import pytest
import json
import data as d

def test_login():
    url = d.login["url_login"]

    payload = json.dumps({
        "email": d.login["email"],
        "password": d.login["password"]
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res = json.loads(response.text)
    assert res["user"]["email"] == d.login["email"]

def test_login_notExistsUser():
    url = d.login_notExistsUser["url_login"]

    payload = json.dumps({
        "email": d.login_notExistsUser["email"],
        "password": d.login_notExistsUser["password"]
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res = json.loads(response.text)
    print(response.text)
    assert res["detail"] == "No active account found with the given credentials"

def test_wrong_pwd():
    url = d.login_notExistsUser["url_login"]

    payload = json.dumps({
        "email": d.login_notExistsUser["email"],
        "password": "wrongPwd"
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res = json.loads(response.text)
    print(response.text)
    assert res["detail"] == "No active account found with the given credentials"    

if __name__ == '__main__':
    pytest.main(['test_login.py'])
    # test_login_notExistsUser()
    test_wrong_pwd()
