import requests
import pytest
import json
import data as d

def test_registration():
    url = d.registration["url_registration"]

    payload = json.dumps({
        "email": d.registration["email"],
        "password": d.registration["password"],
        "firstName": d.registration["firstName"],
        "lastName": d.registration["lastName"],
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res = json.loads(response.text)
    assert res["user"]["lastName"] == d.registration["lastName"]


def test_registration_emailError():
    url = d.registration_emailError["url_registration"]

    payload = json.dumps({
        "email": d.registration_emailError["email"],
        "password": d.registration_emailError["password"],
        "firstName": d.registration_emailError["firstName"],
        "lastName": d.registration_emailError["lastName"],
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res = json.loads(response.text)
    print(response.text)
    assert res["email"] == ["Enter a valid email address."]

if __name__ == '__main__':
    pytest.main(['test_registraion.py'])
    # test_registration_emailError()

