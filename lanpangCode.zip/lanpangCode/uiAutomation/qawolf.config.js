module.exports = {
  config: "node_modules/qawolf/js-jest.config.json",
  rootDir: ".qawolf",
  testTimeout: 60000,
  useTypeScript: false
}
