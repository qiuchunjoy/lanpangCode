module.exports={
    browsers:["chromium"],
    launchOptions: {
        headless: false,
        // 不进行延时设置，会使得调用方法时候报null错误
        slowMo: 500
    }
}