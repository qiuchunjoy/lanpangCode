// 处理错误，放置截图到制定路径
const PlaywrightEnvironment = require('jest-playwright-preset/lib/PlaywrightEnvironment').default


class CustomEnvironment extends PlaywrightEnvironment {
    // async setup() {
    //     await super.setup()
    //     // Your setup
    // }


    // async teardown() {
    //     // Your teardown
    //     await super.teardown()
    // }


    async handleTestEvent(event) {
        if (event.name === 'test_done' && event.test.errors.length > 0) {
            //是否错误用例才截图这里改代码
            const parentName = event.test.parent.name.replace(/\W/g, '-')
            const specName = event.test.name.replace(/\W/g, '-')


            await this.global.page.screenshot({
                path: `screenshots/${parentName} ${specName}.png`,
            })
        }
    }
}

module.exports = CustomEnvironment