const {
    TestScheduler
} = require('jest')

// import reporters which helps you make a screenshot after each test step
const {
    addAttach
} = require('jest-html-reporters/helper')

describe('All', () => {

    beforeAll(async () => {
        await page.waitForLoadState()
    })

    test('lanpang', async () => {
        const page = await context.newPage()
        await Promise.all([
            await page.goto("https://weathershopper.pythonanywhere.com/", { waitUntil: "domcontentloaded" }),
            await page.click(".btn"),
            await page.goBack(),
            await page.click('text="Buy sunscreens"'),
            await page.goBack()

        ])
    })

    // add screenshot after each test
    afterEach(async () => {
        const after_test = await page.screenshot({
            delay: 1000,
        })
        await addAttach(after_test)
    })
})